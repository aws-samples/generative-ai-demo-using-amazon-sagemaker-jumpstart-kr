// import * as cdk from 'aws-cdk-lib';
// import { Template } from 'aws-cdk-lib/assertions';
// import * as CdkChatbotLlama2 from '../lib/cdk-chatbot-llama2-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/cdk-chatbot-llama2-stack.ts
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new CdkChatbotLlama2.CdkChatbotLlama2Stack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
