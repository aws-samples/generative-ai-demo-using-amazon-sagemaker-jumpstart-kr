// import * as cdk from 'aws-cdk-lib';
// import { Template } from 'aws-cdk-lib/assertions';
// import * as CdkRagChatbotWithKendra from '../lib/cdk-rag-chatbot-with-kendra-stack';

// example test. To run these tests, uncomment this file along with the
// example resource in lib/cdk-rag-chatbot-with-kendra-stack.ts
test('SQS Queue Created', () => {
//   const app = new cdk.App();
//     // WHEN
//   const stack = new CdkRagChatbotWithKendra.CdkRagChatbotWithKendraStack(app, 'MyTestStack');
//     // THEN
//   const template = Template.fromStack(stack);

//   template.hasResourceProperties('AWS::SQS::Queue', {
//     VisibilityTimeout: 300
//   });
});
