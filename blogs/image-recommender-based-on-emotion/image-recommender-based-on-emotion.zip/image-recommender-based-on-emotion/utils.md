# 유용한 툴들

## 이미지 Pool에서 이미지 확인 및 삭제

1) imgPool 폴더에 신규 Object가 생성 event를 이용하여 DynamoDB에 기록합니다.
2) Previwer 툴을 이용하여 생성된 이미지의 리스트를 확인하고 필요시 삭제합니다.
